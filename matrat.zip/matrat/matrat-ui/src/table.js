import React, { useEffect } from 'react';
import MaterialTable from 'material-table';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';
import NativeSelect from '@material-ui/core/NativeSelect';
import InputLabel from '@material-ui/core/InputLabel';

export default function MaterialTableDemo() {
  const [state, setState] = React.useState({
    columns: [

      { title: 'Age', field: 'age' ,
        editComponent: props => (
        <FormControl >
        <InputLabel htmlFor="age-native-simple">Age</InputLabel>
        <Select
          native
          value={props.rowData.age?props.rowData.age:'20'}
          onChange={(e)=>props.onChange(e.target.value)}
          inputProps={{
            name: 'age',
            id: 'age-native-simple',
          }}
        >
           <option value={''}>None</option>
          <option value={'10'}>Ten</option>
          <option value={'20'}>Twenty</option>
          <option value={'30'}>Thirty</option>
        </Select>
      </FormControl>
      )},
      { title: 'Surname', field: 'surname' },
      { title: 'Birth Year', field: 'birthYear', type: 'numeric' },
      {
        title: 'Birth Place',
        field: 'birthCity',
        lookup: { 34: 'İstanbul', 63: 'Şanlıurfa' },
      },
    ],
    data: [
      { age: '10', surname: 'Baran', birthYear: 1987, birthCity: 63 },
      {
        age: '20',
        surname: 'Baran',
        birthYear: 2017,
        birthCity: 34,
      },
    ],
  });

  useEffect(()=>{
    console.log("New State",state.data)
    
  },[state.data])

  return (
    <MaterialTable
      title="Editable Example"
      columns={state.columns}
      data={state.data}
      editable={{
        onRowAdd: (newData) =>
          new Promise((resolve) => {
            setTimeout(() => {
              resolve();
              setState((prevState) => {
                const data = [...prevState.data];
                data.push(newData);
                return { ...prevState, data };
              });
            }, 600);
          }),
        onRowUpdate: (newData, oldData) =>
          new Promise((resolve) => {
            setTimeout(() => {
              resolve();
              if (oldData) {
                setState((prevState) => {
                  const data = [...prevState.data];
                  data[data.indexOf(oldData)] = newData;
                  return { ...prevState, data };
                });
              }
            }, 600);
          }),
        onRowDelete: (oldData) =>
          new Promise((resolve) => {
            setTimeout(() => {
              resolve();
              setState((prevState) => {
                const data = [...prevState.data];
                data.splice(data.indexOf(oldData), 1);
                return { ...prevState, data };
              });
            }, 600);
          }),
      }}
    />
  );
}
