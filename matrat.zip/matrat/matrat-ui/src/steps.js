import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Button from '@material-ui/core/Button';
import Container from '@material-ui/core/Container'
import {Router, Route, Switch} from 'react-router-dom'
import AppCard from './Appcard';
import StepOne from './StepOne'
import StepTwo from './StepTwo'
import StepThree from './StepThree'


import { createBrowserHistory } from 'history'
let history=createBrowserHistory()

console.log("History",history)


const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
  },

  instructions: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },

  content:{
    backgroundColor:'yellow',
    border:'2px solid black',
    width:'100vw',
    height:'70vh'

  }
}));

function getStepContent(stepIndex, classes) {
 return (
   <Container maxWidth='xs' className={classes.content}>
     <AppCard header='This is header' info=' this is info this is info this is info'/>
     <div>
       <h2>This is My step container!</h2>
       <br></br>
       <p>This is My step container! This is My step container!This is My step container! This is My step container!</p>
     </div>
   </Container>
 )
}

function MyStepper(props) {
  console.log("Props",props)
  let classes = useStyles();
  const [activeStep, setActiveStep] = React.useState(0);

  const handleNext = () => {
     setActiveStep(prevActiveStep => prevActiveStep + 1);
    history.push(`/step${activeStep+2}`)
  };


  return (
    <Router history={history}>
    <div className={classes.root}>
      <Stepper activeStep={activeStep}>
        {[1,2,3].map(step => (
          <Step key={step}>
            <StepLabel/>
          </Step>
        ))}
      </Stepper>
          <div>
          <Switch>
              <Route path="/" exact component={StepOne}/>
              <Route path="/step2" exact component={StepTwo}/>
              <Route path="/step3" exact component={StepThree}/>
          </Switch>
            <div>
              <Button variant="contained" color="primary" onClick={handleNext}>
               Next
              </Button>
            </div>
          </div>
      </div>
      </Router>
  );
}


export default MyStepper