import React from 'react'

class StepOne extends React.Component{


    render(){
        return(
            <div>
                This is StepTwo!
            </div>
        )
    }
}

export default StepOne