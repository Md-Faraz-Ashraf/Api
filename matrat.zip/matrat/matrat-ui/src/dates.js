import "date-fns";
import React from "react";
import moment from 'moment'
import Grid from "@material-ui/core/Grid";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  TimePicker,
  KeyboardDatePicker,
} from "@material-ui/pickers";

export default function MaterialUIPickers() {
  // The first commit of Material-UI

  const [selectedDate, setSelectedDate ] = React.useState(moment("12:30", "HH:mm"))
  const [time, setTime] = React.useState('02:35')
  const handleDateChange = (time) => {
    console.log("--------")
    //PT14H00M00S
    console.log("Hours", time.getHours())
    console.log("Minutes", time.getMinutes())
    console.log("Expexted Time format",time)
    setSelectedDate(time);
  };

  const handleTimeChange= (time) => {
    console.log("time",typeof(time))
    console.log("time",time)
    setTime(time)
  }

  return (
    <React.Fragment>
      <MuiPickersUtilsProvider utils={DateFnsUtils}>
        <Grid container justify="space-around">
          <TimePicker value={selectedDate} onChange={handleDateChange} />
        </Grid>

        <KeyboardTimePicker
          label="Masked timepicker"
          placeholder="08:00 AM"
          value={selectedDate}
          onChange={handleDateChange}
        />

        
<input
          type="time"
          value={time}
          className="form-control"
          placeholder="Time"
          onChange={(ev) => {handleTimeChange(ev.target.value)}}
        />

        <KeyboardTimePicker
          margin="normal"
          id="time-picker"
          label="Time picker"
          value={selectedDate}
          onChange={handleDateChange}
          KeyboardButtonProps={{
            "aria-label": "change time",
          }}
        />
      </MuiPickersUtilsProvider>
    </React.Fragment>
  );
}
