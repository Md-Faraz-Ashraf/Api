import React from 'react';
import 'date-fns';
import { makeStyles } from '@material-ui/core/styles';
import {Typography, TextField} from '@material-ui/core';
import { KeyboardDatePicker } from "@material-ui/pickers";
import { MuiPickersUtilsProvider } from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import Checkbox from '@material-ui/core/Checkbox'
import Container from '@material-ui/core/Container'
import Button from '@material-ui/core/Button'
import Grid from '@material-ui/core/Grid'
import Divider from '@material-ui/core/Divider'
import { ExpansionPanel } from '@material-ui/core';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';

const useStyles = makeStyles(() => ({
  fields:{
    margin:'2px',
    width:'15rem'
  },
  btn:{
    marginBottom:'20px',
    float:'right'
  }

}));

export default function Register() {
  const classes = useStyles();

  const [selectedDate, setSelectedDate] = React.useState();

  const handleDateChange = date => {
    setSelectedDate(date);
  };


   const [checked, setChecked] = React.useState(true);

  const handleChange = event => {
    setChecked(event.target.checked);
  };

  return(
    <Container className={classes.container}>
       <Typography className={classes.items}>Welcome to Relocation Process</Typography>
          <Typography>Register</Typography>
    <Grid container className={classes.container}>
        <Grid item lg={12} xs={12} md={12}>
              <Grid container>
                  <Grid item lg={6} xs={12} md={6}>
                          <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                  </Grid>
                  <Grid item lg={6} xs={12} md={6}>
                          <TextField id="filled-basic" label="Last name" variant="filled" className={classes.fields}/>
                  </Grid>
                  <Grid item lg={6} xs={12} md={6}>
                          <MuiPickersUtilsProvider utils={DateFnsUtils}>
                          <KeyboardDatePicker 
                              onChange={handleDateChange}
                              value={selectedDate}
                              placeholder="BirthDay"
                              margin="normal"
                              id="date-picker-dialog"
                              label="Birth day"
                              format="MM/dd/yyyy"
                              className={classes.fields}  
                            />
                          </MuiPickersUtilsProvider>
                  </Grid>

          <Grid item lg={3} xs={12} md={6}>
              <ExpansionPanel>
                <ExpansionPanelSummary>
                    <Typography >Expansion Panel 1</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                </ExpansionPanelDetails>
              </ExpansionPanel>
          </Grid>

          <Grid item lg={3} xs={12} md={6}>
              <ExpansionPanel>
                <ExpansionPanelSummary>
                    <Typography >Expansion Panel 1</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails style={{"display":'block'}}>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                </ExpansionPanelDetails>
              </ExpansionPanel>
          </Grid>

          <Grid item lg={3} xs={12} md={6}>
              <ExpansionPanel>
                <ExpansionPanelSummary>
                    <Typography >Expansion Panel 1</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
                </ExpansionPanelDetails>
              </ExpansionPanel>
          </Grid>
            </Grid>
       </Grid>
          <Grid item lg={12} xs={12} md={12}>
          <Divider/>
            <Grid container>
                  <Grid item lg={6} xs={12} md={6}>
                      <TextField id="filled-basic" label="Password" variant="filled" className={classes.fields}/>
                  </Grid>
                  <Grid item lg={6} xs={12} md={6}>
                          <TextField id="filled-basic" label="Confirm Password" variant="filled" className={classes.fields}/>
                  </Grid>
                  <Grid item lg={6} xs={12} md={6}>
                          <TextField id="filled-basic" label="Confirm Password" variant="filled" className={classes.fields}/>
                  </Grid>
              </Grid>
          </Grid>
  </Grid>
    <div>
    <label>
      <input type="checkbox" /> Label text needs to be really really long to show this in action. Label text needs to be really really long to show this in action. Label text needs to be really really long to show this in action. Label text needs to be really really long to show this in action. Label text needs to be really really long to show this in action.</label>
      <div>
      <Button variant="contained" color="primary" className={classes.btn}>Register</Button>
      </div>
   
      <ExpansionPanel>
        <ExpansionPanelSummary>
          <Typography >Expansion Panel 1</Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
        <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
        <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
        <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
         <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}/>
        </ExpansionPanelDetails>
      </ExpansionPanel>
    </div>
    </Container>
  )
}