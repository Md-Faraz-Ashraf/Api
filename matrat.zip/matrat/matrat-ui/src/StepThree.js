import React from 'react'

class StepOne extends React.Component{


    render(){
        return(
            <div>
                This is StepThree!
            </div>
        )
    }
}

export default StepOne