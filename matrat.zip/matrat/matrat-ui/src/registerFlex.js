import React from 'react';
import 'date-fns';
import { makeStyles } from '@material-ui/core/styles';
import {Typography, TextField} from '@material-ui/core';
import { KeyboardDatePicker } from "@material-ui/pickers";
import { MuiPickersUtilsProvider } from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import Checkbox from '@material-ui/core/Checkbox'
import Container from '@material-ui/core/Container'
import Button from '@material-ui/core/Button'

const useStyles = makeStyles(() => ({
  fields:{
    margin:'2px',
    width:'15rem'
  },
  container:{
    marginTop:'20px',
    display:'flex',
    flexDirection:'column',
    border:'2px solid black',
    borderBottomRightRadius:'40px',
    maxWidth:'80vw',
    backgroundColor:'white'
  },
  upperContainer:{
    display:'flex',
    justifyContent:'center',
    flexDirection:'column',
   
    alignItems:'center',
    maxWidth:'xs',

  },
  lowerContainer:{
    diaply:'flex',
  
  },

  btn:{
    marginBottom:'20px',
    float:'right'
  }

}));

export default function Register() {
  const classes = useStyles();

  const [selectedDate, setSelectedDate] = React.useState();

  const handleDateChange = date => {
    setSelectedDate(date);
  };


   const [checked, setChecked] = React.useState(true);

  const handleChange = event => {
    setChecked(event.target.checked);
  };

  return(
    <Container maxWidth='xs' className={classes.container}>
    <div className={classes.upperContainer}>
      <Typography className={classes.items}>Welcome to Relocation Process</Typography>
      <Typography>Register</Typography>
      <TextField  id="filled-basic" label="First Name" variant="filled" className={classes.fields} required={true}  />
      <TextField id="filled-basic" label="Last name" variant="filled" className={classes.fields}/>
      <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <KeyboardDatePicker 
          onChange={handleDateChange}
          value={selectedDate}
          placeholder="BirthDay"
          margin="normal"
          id="date-picker-dialog"
          label="Birth day"
          format="MM/dd/yyyy"
          className={classes.fields}
         
        />
      </MuiPickersUtilsProvider>
      <TextField id="filled-basic" label="Phone" variant="filled" className={classes.fields}/>
      <TextField id="filled-basic" label="Password" variant="filled" className={classes.fields}/>
      <TextField id="filled-basic" label="Confirm Password" variant="filled" className={classes.fields}/>
      <TextField id="filled-basic" label="Confirm Password" variant="filled" className={classes.fields}/>
    </div>
    <div>
    <label>
      <input type="checkbox" /> Label text needs to be really really long to show this in action. Label text needs to be really really long to show this in action. Label text needs to be really really long to show this in action. Label text needs to be really really long to show this in action. Label text needs to be really really long to show this in action.</label>
      <div>
      <Button variant="contained" color="primary" className={classes.btn}>Register</Button>
      </div>
    </div>
   
    </Container>
  )
}