import React from 'react'
import AppCard from './Appcard'
import Container from '@material-ui/core/Container'
import { makeStyles } from '@material-ui/core/styles';

function  StepOne(){

    const useStyles = makeStyles(theme => ({
        content:{
          backgroundColor:'white',
          border:'2px solid black',
          width:'90vw',
          height:'65vh'
        }
      }));

    function getStepContent(stepIndex, classes) {
        return (
          <Container maxWidth='xs' className={classes.content}>
            <AppCard header='This is header' info=' this is info this is info this is info'/>
            <div>
              <h2>This is My step container!</h2>
              <br></br>
              <p>This is My step container! This is My step container!This is My step container! This is My step container!</p>
            </div>
          </Container>
        )
       }

       let classes = useStyles();


        return(
            <div>
                {getStepContent(1,classes)}
            </div>
        )
    }


export default StepOne