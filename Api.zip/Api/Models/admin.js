const mongoose = require('mongoose')
const schema = require('../Schema')
const adminSchema = schema.adminSchema
// Here we are creating users class with adminSchema property. And this class is the collection name in db.
module.exports = mongoose.model('admin',adminSchema)



