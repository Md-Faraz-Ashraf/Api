const userModel = require('./users')
const adminModel =require('./admin')

module.exports = {userModel,adminModel}