const mongoose = require('mongoose')
const schema = require('../Schema')
const userSchema = schema.userSchema

// Here we are creating users class with userSchema property. And this class is the collection name in db.
module.exports = mongoose.model('users',userSchema) // connecting our schema to db collection.



