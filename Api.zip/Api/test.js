var records=[{
    'a':1,
    'b':2,
    'c':3
  },
  {
    'a':4,
    'b':5,
    'c':6 
  }]

 const transform_records=(records)=>{
     
    temp=[]
    records.map((record=>{
    const {a,b}=record
    temp.push({'a':a,'b':b}) 
    }))

    return temp
    
 }

 console.log(transform_records(records))

 