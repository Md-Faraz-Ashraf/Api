const mongoose =require('mongoose')
const models = require('../../Models')
const users = models.userModel

 const addUser = async (body)=>{
    const user1= new users(body)
    return await user1.save((err,resp)=>{
        if(!err){
            console.log("SAVED!")
        }
    }).then(result=>{
        console.log("user saved ")
        return result
    }).catch(err=>{
        console.log("err",err)
    })
}

const findUser = async (name)=>{
    console.log(name)
    return await users.find({"name": name}).then(res=>{
       if (!res.length){
           return {"error":"Not Found"}
       }
       else{
           return res
       }
    }
        ).catch(err=>console.log("error in finding"))
}



module.exports = {addUser, findUser}

