const mongoose = require('mongoose')

var mongoDB = 'mongodb://localhost:27017/people';

const connection=mongoose.connect(mongoDB).then((result)=>{console.log("Connection established",result)}).catch(err=>{console.log("error",err)})
