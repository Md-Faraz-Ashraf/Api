const express = require('express')
const router = express.Router()

const userFuncs = require('../Database/Repository/usersRepo')

router.get('/:name',(req,res)=>{
    console.log(req.params)
    userFuncs.findUser(req.params.name).then((result)=>{
        console.log("result",result)
        res.send(result)
    }     
    )
})

router.post('/',(req,res)=>{
    console.log("inside post")
    userFuncs.addUser(req.body).then(
        (err,result)=>{
            if (!err){
                res.json(result)
            }
            res.send(err)
        }
       
    )
})



module.exports = router



