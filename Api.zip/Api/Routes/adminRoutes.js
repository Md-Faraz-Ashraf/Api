const express = require('express')
const router = express.Router()

const admin = require('../Models/admin')

router.get('/',(req,res)=>{
    console.log("getting admin")
    res.end()
})

module.exports = router



