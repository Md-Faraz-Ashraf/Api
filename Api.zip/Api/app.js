const express = require('express')
const bodyParser = require('body-parser')
const userRoutes = require('./Routes/userRoutes')
const adminRoutes = require('./Routes/adminRoutes')
const router=express.Router()
const connection = require('./Database/connections')

const expressApp = express()

expressApp.use(bodyParser.json())
expressApp.use('/users',userRoutes)
expressApp.use('/admin',adminRoutes)

expressApp.listen(3001,()=>{
    console.log("Api app star ted at port 3001 !")
    
})
