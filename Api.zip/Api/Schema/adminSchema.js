const mongoose = require('mongoose')


//Here we are defining the properties for the user class and call it admin schema.
const adminSchema= new mongoose.Schema({
    "name":String,
    "age":Number,
    "password":Number,
    "email":String,
    "role":String
})

module.exports = adminSchema
