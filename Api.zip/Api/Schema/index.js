var userSchema = require('./userSchema')
var adminSchema = require('./adminSchema')

module.exports = {userSchema,adminSchema}