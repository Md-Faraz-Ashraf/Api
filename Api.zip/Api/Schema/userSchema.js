const mongoose = require('mongoose')
//Here we are defining the properties for the user class and call it user schema.
const userSchema= new mongoose.Schema({
    "name":String,
    "age":Number,
    "password":Number,
    "email":String
})

module.exports= userSchema