const mongoose = require('mongoose')
// Requiring Schema constructor from mongoose.
//Note you are imporing schema class not schema()
const Schema = mongoose.Schema

// Creating our own schema constuctor.
const PatientSchema = new Schema({
    name:{
        type:String,
        required:true
    },
    age:{
        type:Number,
        required:true
    },
    phone:{
        type:Number,
        required:true
    },
    address:{
        type:String,
        required:true
    },
    email:{
        type:String,
        requird:true
    },
    password:{
        type:String,
        required:true
    }
})

// Model is an instance of schema that binds the collection in db to schema.
// This means that a the patient collection in db has structure like PatientSchema.
// Note collection name below comes in quotes.
const PatientModel =  mongoose.model('patient',PatientSchema)

module.exports= PatientModel