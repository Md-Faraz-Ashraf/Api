const mongoose = require('mongoose')
const URL= require('../config/dbConfig').dbURL

// Making connection to Db.
const connection = mongoose
                        .connect(URL)
                        .then(result=>console.log("connected to db- "))
                        .catch(err=> console.log("Error connecting db- ",err))

// Exporting the connection Object.
module.exports = connection