module.exports = {
    dbURL :"mongodb://localhost:27017/hospital"
}