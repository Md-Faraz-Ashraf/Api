const express = require('express')
const mongoose = require('mongoose')
const Patient = require('../../Models/patientModel')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

const secret = require('../../config/key').secretKey


const router = express.Router()

router.post('/patient',(req,res)=>{
    const {email,password} = req.body
    console.log(email,password)
    Patient.find({email})
    .then(user=>{
        if(user){
            console.log("opwd",user)
            bcrypt.compare(password,user.password).then(isMatch=>{
                if(isMatch){
                    jwt.sign(
                        user,
                        secret,
                        {expiresIn: 3600},
                        (err,token)=>{
                            console.log("3333333333")
                            res.json({
                                success:true,
                                token: 'Bearer '+ token     
                            })
                    })
                }
                else{
                    return res.statusCode(400).json({
                        "password":"password Incorrect"
                    })
                }
                 
            })
        }else{
            return res.status(404).json({email: "User Not found"})
        }
    })

})

module.exports = router