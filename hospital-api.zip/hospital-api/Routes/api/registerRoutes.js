const express = require('express')
const router = express.Router()
const bcrypt = require('bcryptjs')

// This Patient is Model what we can use to interact with patient collection in db.
// We can use any mongoose method with it now. 
const  Patient =  require('../../Models/patientModel')

router.post('/patient',(req,res)=>{
    //Patient = new Patient(req.body) 
     // Before registering check if patient already exists.  
    Patient.findOne({email:req.body.email}).
        then(user => {
            if(user){
                return res.status(400).json({"email":"email already exists"})
            }
            else{
                const newUser = Patient({
                    name:req.body.name,
                    age:req.body.age,
                    email:req.body.email,
                    phone:req.body.phone,
                    address:req.body.address,
                    password: req.body.password
                 })
                     bcrypt.genSalt(10, (err,salt)=>{
                        bcrypt.hash(newUser.password,salt, (err,hash)=>{
                            if(err) throw err;
                            newUser.password=hash
                            newUser.save()
                                .then(user=>res.json({
                                    status:200,
                                    msg:'User Created',
                                    user,
                                    }))
                                .catch(err=>console.log("Error saving the user- ",err))
                                    })
                             })
                }

        })
        .catch(err=>{console.log("Error checking for user in db -",err)})
})

module.exports = router
